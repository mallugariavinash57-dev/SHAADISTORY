"""Pure filtering helpers shared by the Streamlit UI and its tests."""
from __future__ import annotations

from datetime import date

from ordertracker.models import Order


def filter_orders(
    orders: list[Order],
    query: str = "",
    status: str = "All statuses",
    category: str = "All categories",
    overdue_only: bool = False,
    today: date | None = None,
) -> list[Order]:
    """Filter orders using the same fields exposed in the dashboard."""
    query = query.strip().casefold()
    results = []
    for order in orders:
        if status != "All statuses" and order.status != status:
            continue
        if category != "All categories" and order.category != category:
            continue
        if query and query not in " ".join(
            (order.order_id, order.customer, order.item, order.notes)
        ).casefold():
            continue
        if overdue_only and not order.is_overdue(today):
            continue
        results.append(order)
    return results
