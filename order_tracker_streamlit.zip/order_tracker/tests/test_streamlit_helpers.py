import unittest
from datetime import date

from ordertracker.models import Order
from streamlit_helpers import filter_orders


class FilterOrdersTests(unittest.TestCase):
    def setUp(self):
        self.orders = [
            Order('ORD-0001', 'Asha Rao', 'Notebook', 'stationery', 2, 5.0,
                  '2026-11-01', '2026-11-03', 'placed'),
            Order('ORD-0002', 'Milan Shah', 'Tea', 'grocery', 1, 12.0,
                  '2026-11-02', '2026-11-10', 'delivered'),
        ]

    def test_filters_by_keyword_status_category_and_overdue(self):
        results = filter_orders(self.orders, query='asha', status='placed',
                                category='stationery', overdue_only=True,
                                today=date(2026, 11, 5))
        self.assertEqual([order.order_id for order in results], ['ORD-0001'])

    def test_empty_filters_preserve_all_orders(self):
        self.assertEqual(filter_orders(self.orders), self.orders)


if __name__ == '__main__':
    unittest.main()
