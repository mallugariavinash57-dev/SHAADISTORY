import json
import sys
import tempfile
import unittest
from datetime import date
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from ordertracker import validation as v, reports  # noqa: E402
from ordertracker.importer import import_csv        # noqa: E402
from ordertracker.logic import OrderBook            # noqa: E402

ROOT = Path(__file__).resolve().parent.parent


def new_book(tmp):
    return OrderBook(Path(tmp) / "orders.json")


def add_one(book, **kw):
    args = dict(customer="Test User", item="Widget", category="home", quantity=2,
                unit_price="10.50", order_date="2026-11-01", due_date="2026-11-08")
    args.update(kw)
    return book.add(**args)


class ValidationTests(unittest.TestCase):
    def test_quantity(self):
        self.assertEqual(v.parse_quantity("5"), 5)
        for bad in ["", "abc", "0", "-1", "1001", "2.5"]:
            with self.assertRaises(ValueError):
                v.parse_quantity(bad)

    def test_price(self):
        self.assertEqual(v.parse_price("₹1,299.999"), 1300.0)
        for bad in ["", "free", "0", "nan", "inf", "100001"]:
            with self.assertRaises(ValueError):
                v.parse_price(bad)

    def test_date(self):
        self.assertEqual(v.parse_date("2026-02-28"), "2026-02-28")
        for bad in ["2026-02-30", "28/02/2026", "", "tomorrow"]:
            with self.assertRaises(ValueError):
                v.parse_date(bad)

    def test_text_and_id(self):
        self.assertEqual(v.clean_text("  A   B\t", "x"), "A B")
        with self.assertRaises(ValueError):
            v.clean_text("   ", "x")
        self.assertEqual(v.parse_order_id("7"), "ORD-0007")


class LogicTests(unittest.TestCase):
    def test_lifecycle_and_persistence(self):
        with tempfile.TemporaryDirectory() as tmp:
            b = new_book(tmp)
            o = add_one(b)
            self.assertEqual(o.order_id, "ORD-0001")
            self.assertEqual(o.total, 21.0)
            for expected in ["processing", "shipped", "delivered"]:
                self.assertEqual(b.advance(o.order_id).status, expected)
            with self.assertRaises(ValueError):
                b.advance(o.order_id)
            b2 = new_book(tmp)                      # simulate restart
            self.assertEqual(b2.get("ORD-0001").status, "delivered")
            self.assertEqual(len(b2.get("1").history), 4)

    def test_cancel_and_invalid(self):
        with tempfile.TemporaryDirectory() as tmp:
            b = new_book(tmp)
            o = add_one(b)
            b.cancel(o.order_id)
            with self.assertRaises(ValueError):
                b.cancel(o.order_id)
            with self.assertRaises(ValueError):
                add_one(b, due_date="2026-10-01")
            with self.assertRaises(KeyError):
                b.get("ORD-0999")

    def test_search_and_overdue(self):
        with tempfile.TemporaryDirectory() as tmp:
            b = new_book(tmp)
            add_one(b, customer="Alice", item="Lamp", category="home")
            add_one(b, customer="Bob", item="Cable", category="electronics",
                    due_date="2026-12-30")
            self.assertEqual(len(b.search("alice")), 1)
            self.assertEqual(len(b.search(category="electronics")), 1)
            self.assertEqual(len(b.overdue(date(2026, 11, 21))), 1)


class StorageTests(unittest.TestCase):
    def test_corrupt_file_recovers(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "orders.json"
            p.write_text("{ not json", encoding="utf-8")
            b = OrderBook(p)
            self.assertEqual(b.orders, [])
            self.assertTrue(b.load_warnings)
            self.assertTrue(list(Path(tmp).glob("*.corrupt-*")))

    def test_bad_record_skipped(self):
        with tempfile.TemporaryDirectory() as tmp:
            p = Path(tmp) / "orders.json"
            p.write_text(json.dumps({"orders": [{"order_id": "X"}]}), encoding="utf-8")
            b = OrderBook(p)
            self.assertEqual(b.orders, [])
            self.assertIn("Skipped 1", b.load_warnings[0])


class ImportAndReportTests(unittest.TestCase):
    def test_bulk_import_reports_errors(self):
        with tempfile.TemporaryDirectory() as tmp:
            b = new_book(tmp)
            n, errs = import_csv(b, ROOT / "data" / "legacy_import_with_errors.csv",
                                 Path(tmp) / "err.log")
            self.assertEqual(n, 2)
            self.assertEqual(len(errs), 6)
            self.assertTrue((Path(tmp) / "err.log").exists())

    def test_sample_data_loads_and_summarises(self):
        b = OrderBook(ROOT / "data" / "sample_orders.json")
        self.assertEqual(len(b.orders), 40)
        self.assertEqual(b.load_warnings, [])
        s = reports.compute_summary(b.orders, date(2026, 11, 21))
        self.assertEqual(s["total_orders"], 40)
        self.assertGreater(s["overdue_count"], 0)
        self.assertIn("ORDER SUMMARY", reports.format_text(s))
        self.assertIn("| Total orders |", reports.format_markdown(s))

    def test_export(self):
        with tempfile.TemporaryDirectory() as tmp:
            b = OrderBook(ROOT / "data" / "sample_orders.json")
            files = reports.export_all(b.orders, tmp)
            self.assertEqual(len(files), 3)
            self.assertTrue(all(f.stat().st_size > 0 for f in files))


if __name__ == "__main__":
    unittest.main()
