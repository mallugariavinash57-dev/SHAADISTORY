from __future__ import annotations

import tempfile
from datetime import date, timedelta
from pathlib import Path

import pandas as pd
import streamlit as st

from ordertracker import reports, validation
from ordertracker.importer import import_csv
from ordertracker.logic import OrderBook
from ordertracker.models import CATEGORIES, STATUSES
from streamlit_helpers import filter_orders

ROOT = Path(__file__).resolve().parent
DATA_FILE = ROOT / "data" / "orders.json"
EXPORT_DIR = ROOT / "exports"

st.set_page_config(page_title="Order Desk · Order Tracker", page_icon="📦", layout="wide")
st.markdown("""
<style>
@import url('https://fonts.googleapis.com/css2?family=DM+Sans:wght@400;500;600;700&family=Space+Grotesk:wght@500;600;700&display=swap');
html, body, [class*="css"] { font-family: 'DM Sans', sans-serif; }
[data-testid="stAppViewContainer"] { background: #f5f7fb; }
[data-testid="stSidebar"] { background: #101a2b; }
[data-testid="stSidebar"] * { color: #e6edf8 !important; }
.hero { background: linear-gradient(120deg,#13223a,#244a6f); color:#fff; padding:28px 32px; border-radius:18px; margin:0 0 22px; }
.hero h1 { font-family:'Space Grotesk',sans-serif; font-size:32px; margin:0 0 6px; }
.hero p { color:#c8d5e6; margin:0; }
.metric { background:#fff; border:1px solid #e4eaf2; border-radius:14px; padding:16px 18px; }
.metric small { color:#718096; text-transform:uppercase; letter-spacing:.08em; font-size:10px; font-weight:700; }
.metric strong { display:block; color:#13223a; font-size:25px; margin-top:5px; }
section[data-testid="stMain"] { padding-top: 1.5rem; }
</style>
""", unsafe_allow_html=True)

if "order_book" not in st.session_state:
    st.session_state.order_book = OrderBook(DATA_FILE)
book: OrderBook = st.session_state.order_book

with st.sidebar:
    st.markdown("## 📦 Order Desk")
    st.caption("Small-business fulfillment workspace")
    page = st.radio("Workspace", ["Overview", "Orders", "Add order", "Reports", "Import CSV"], label_visibility="collapsed")
    st.divider()
    st.caption(f"{len(book.orders)} orders · local JSON storage")


def metric(label: str, value: str, note: str = "") -> None:
    st.markdown(f'<div class="metric"><small>{label}</small><strong>{value}</strong><span style="color:#718096;font-size:12px">{note}</span></div>', unsafe_allow_html=True)


def order_frame(orders):
    return pd.DataFrame([{
        "Order ID": o.order_id, "Customer": o.customer, "Item": o.item,
        "Category": o.category.title(), "Qty": o.quantity,
        "Total": o.total, "Due date": o.due_date,
        "Status": o.status.title(), "Overdue": o.is_overdue(),
    } for o in orders])


def header(title: str, subtitle: str):
    st.markdown(f'<div class="hero"><h1>{title}</h1><p>{subtitle}</p></div>', unsafe_allow_html=True)


if page == "Overview":
    header("Orders, moving forward.", "A clear view of what's in flight, what's late, and what the business has earned.")
    summary = reports.compute_summary(book.orders)
    c1, c2, c3, c4 = st.columns(4)
    with c1: metric("Total orders", f"{summary['total_orders']:,}", "across all statuses")
    with c2: metric("Open revenue", f"${summary['revenue']:,.2f}", "excludes cancelled orders")
    with c3: metric("Delivery rate", f"{summary['delivery_rate']:.1f}%", "of non-cancelled orders")
    with c4: metric("Needs attention", str(summary['overdue_count']), "currently overdue")
    st.write("")
    left, right = st.columns([1.2, 1])
    with left:
        st.subheader("Order pipeline")
        pipeline = pd.DataFrame({"Status": list(summary["by_status"]), "Orders": list(summary["by_status"].values())})
        st.bar_chart(pipeline.set_index("Status"), color="#4c83d9", height=270)
    with right:
        st.subheader("Revenue by category")
        category_data = pd.DataFrame(list(summary["category_revenue"].items()), columns=["Category", "Revenue"])
        if not category_data.empty:
            st.bar_chart(category_data.set_index("Category"), color="#29a382", height=270)
        else:
            st.info("Add an order to start seeing category revenue.")
    st.subheader("Recent orders")
    st.dataframe(order_frame(sorted(book.orders, key=lambda o: o.order_date, reverse=True)[:8]), hide_index=True, width="stretch")
    if book.load_warnings:
        with st.expander("Data file notes"):
            for warning in book.load_warnings: st.warning(warning)

elif page == "Orders":
    header("Order register", "Find an order by ID, customer or item. Filter by delivery stage and category.")
    a, b, c, d = st.columns([1.5, 1, 1, 1])
    query = a.text_input("Search", placeholder="e.g. ORD-0012 or Maya")
    status = b.selectbox("Status", ["All statuses", *STATUSES])
    category = c.selectbox("Category", ["All categories", *CATEGORIES])
    overdue = d.toggle("Overdue only")
    filtered = filter_orders(book.orders, query, status, category, overdue)
    st.caption(f"Showing {len(filtered)} of {len(book.orders)} orders")
    if filtered:
        st.dataframe(order_frame(filtered), hide_index=True, width="stretch",
                     column_config={"Total": st.column_config.NumberColumn(format="$%.2f"), "Overdue": st.column_config.CheckboxColumn()})
        selected_id = st.selectbox("Open order details", [o.order_id for o in filtered])
        selected = book.get(selected_id)
        with st.expander(f"{selected.item} · {selected.customer}", expanded=False):
            st.write(f"**Total:** ${selected.total:,.2f} · **Due:** {selected.due_date} · **Status:** {selected.status.title()}")
            if selected.notes: st.write(f"Notes: {selected.notes}")
            st.write("**Status history**")
            st.dataframe(pd.DataFrame(selected.history), hide_index=True, width="stretch")
        nxt = book.next_status(selected)
        u1, u2, _ = st.columns([1, 1, 4])
        if nxt and u1.button(f"Advance to {nxt.title()}", type="primary"):
            book.advance(selected_id); st.success(f"{selected_id} moved to {nxt}."); st.rerun()
        if selected.status not in ("delivered", "cancelled") and u2.button("Cancel order"):
            book.cancel(selected_id); st.warning(f"{selected_id} cancelled."); st.rerun()
    else:
        st.info("No orders match those filters.")

elif page == "Add order":
    header("Create an order", "Record the essentials now. Status history and fulfillment metrics update automatically.")
    with st.form("add_order_form", clear_on_submit=True):
        c1, c2, c3 = st.columns(3)
        customer = c1.text_input("Customer name")
        item = c2.text_input("Item")
        category = c3.selectbox("Category", CATEGORIES)
        d1, d2, d3 = st.columns(3)
        quantity = d1.number_input("Quantity", 1, 1000, 1)
        unit_price = d2.number_input("Unit price ($)", min_value=0.01, max_value=100000.0, value=24.99, step=0.5)
        order_date = d3.date_input("Order date", value=date.today())
        due_date = st.date_input("Due date", value=date.today() + timedelta(days=7))
        notes = st.text_area("Notes", max_chars=200)
        submitted = st.form_submit_button("Save order", type="primary")
    if submitted:
        try:
            order = book.add(customer, item, category, quantity, unit_price, order_date.isoformat(), due_date.isoformat(), notes)
            st.success(f"{order.order_id} created · ${order.total:,.2f}")
            if order.total >= reports.HIGH_VALUE_LIMIT: st.warning("High-value order — please double-check details.")
            st.rerun()
        except ValueError as exc:
            st.error(str(exc))

elif page == "Reports":
    header("Reports & trends", "Understand order volume, revenue, fulfillment, and customer value.")
    summary = reports.compute_summary(book.orders)
    m1, m2, m3 = st.columns(3)
    with m1: metric("Average order", f"${summary['avg_order_value']:,.2f}")
    with m2: metric("Avg. fulfillment", f"{summary['avg_fulfilment_days']} days" if summary['avg_fulfilment_days'] is not None else "—")
    with m3: metric("High value", str(summary['high_value_count']), "orders ≥ $10,000")
    c1, c2 = st.columns(2)
    with c1:
        st.subheader("Monthly orders")
        monthly = pd.DataFrame(list(summary["monthly_orders"].items()), columns=["Month", "Orders"])
        if not monthly.empty: st.line_chart(monthly.set_index("Month"), color="#4c83d9")
        else: st.info("No order dates to chart yet.")
    with c2:
        st.subheader("Top customers")
        top = pd.DataFrame(summary["top_customers"], columns=["Customer", "Revenue"])
        if not top.empty: st.dataframe(top, hide_index=True, width="stretch", column_config={"Revenue": st.column_config.NumberColumn(format="$%.2f")})
        else: st.info("No customer revenue to report yet.")
    if st.button("Generate report files"):
        files = reports.export_all(book.orders, EXPORT_DIR)
        st.success("Reports saved in the exports folder.")
        for path in files:
            st.download_button(f"Download {path.name}", path.read_bytes(), file_name=path.name, key=f"download-{path.name}")

elif page == "Import CSV":
    header("Bring orders in", "Upload a CSV with customer, item, category, quantity, unit_price, order_date and due_date columns.")
    upload = st.file_uploader("Select a CSV file", type=["csv"])
    if upload and st.button("Import valid rows", type="primary"):
        tmp_path = None
        try:
            with tempfile.NamedTemporaryFile(mode="wb", suffix=".csv", delete=False) as tmp:
                tmp.write(upload.getvalue()); tmp_path = Path(tmp.name)
            imported, errors = import_csv(book, tmp_path, ROOT / "data" / "import_errors.log")
            st.success(f"Imported {imported} order(s).")
            if errors:
                st.warning(f"{len(errors)} row(s) were skipped.")
                st.code("\n".join(errors[:30]))
            st.rerun()
        except Exception as exc:
            st.error(f"Import failed: {exc}")
        finally:
            if tmp_path and tmp_path.exists(): tmp_path.unlink()
