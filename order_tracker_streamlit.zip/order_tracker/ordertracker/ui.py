"""Menu-driven terminal interface with ANSI colours and paginated tables."""
from __future__ import annotations

import os
import sys
from datetime import date, timedelta
from pathlib import Path

from . import reports, validation as v
from .importer import import_csv
from .logic import OrderBook
from .models import CATEGORIES, STATUSES, Order

USE_COLOR = sys.stdout.isatty() and not os.environ.get("NO_COLOR")
PAGE_SIZE = 10


def c(text: str, code: str) -> str:
    return f"\033[{code}m{text}\033[0m" if USE_COLOR else text


BOLD, RED, GREEN, YELLOW, CYAN, DIM = "1", "31", "32", "33", "36", "2"
STATUS_COLOR = {"placed": YELLOW, "processing": CYAN, "shipped": "34",
                "delivered": GREEN, "cancelled": DIM}

BANNER = r"""
  ╔══════════════════════════════════════════════╗
  ║        SIMPLE ORDER TRACKER  v1.0            ║
  ║   record  ·  track  ·  deliver  ·  report    ║
  ╚══════════════════════════════════════════════╝"""

MENU = """
  1) Add new order            6) Summary report
  2) Update order status      7) Overdue warnings
  3) View all orders          8) Export reports
  4) Search / filter          9) Bulk import CSV
  5) Order details            0) Exit"""


def trunc(s: str, n: int) -> str:
    return s if len(s) <= n else s[: n - 1] + "…"


def print_table(orders: list[Order], today: date | None = None, input_fn=input) -> None:
    if not orders:
        print(c("  No matching orders.", YELLOW))
        return
    today = today or date.today()
    head = (f"  {'ID':<9}{'Customer':<17}{'Item':<20}{'Category':<12}"
            f"{'Qty':>4} {'Total':>11}  {'Due':<11}{'Status'}")
    for start in range(0, len(orders), PAGE_SIZE):
        print(c(head, BOLD))
        print("  " + "-" * (len(head) - 2))
        for o in orders[start:start + PAGE_SIZE]:
            flag = c("!", RED) if o.is_overdue(today) else " "
            status = c(f"{o.status:<10}", STATUS_COLOR.get(o.status, "0"))
            print(f"  {o.order_id:<9}{trunc(o.customer, 16):<17}{trunc(o.item, 19):<20}"
                  f"{o.category:<12}{o.quantity:>4} {o.total:>11,.2f}  {o.due_date:<10}{flag}{status}")
        shown = min(start + PAGE_SIZE, len(orders))
        print(c(f"  Showing {shown} of {len(orders)}  (! = overdue)", DIM))
        if shown < len(orders):
            if input_fn("  Press Enter for next page, or q to stop: ").strip().lower() == "q":
                break


# ---- actions ---------------------------------------------------------------
def add_order(book: OrderBook) -> None:
    print(c("\n  New order  (type 'cancel' at any prompt to abort)", BOLD))
    today = date.today().isoformat()
    customer = v.ask("  Customer name", lambda s: v.clean_text(s, "Customer"))
    item = v.ask("  Item", lambda s: v.clean_text(s, "Item"))
    category = v.ask(f"  Category ({'/'.join(CATEGORIES)})", v.parse_category)
    qty = v.ask("  Quantity", v.parse_quantity)
    price = v.ask("  Unit price", v.parse_price)
    order_date = v.ask("  Order date YYYY-MM-DD", v.parse_date, default=today)
    default_due = (date.fromisoformat(order_date) + timedelta(days=7)).isoformat()

    def due_parser(s):
        d = v.parse_date(s)
        v.validate_dates(order_date, d)
        return d
    due = v.ask("  Due date YYYY-MM-DD", due_parser, default=default_due)
    notes = v.ask("  Notes (optional)", lambda s: v.clean_text(s, "Notes", 0, 200), default="")
    o = book.add(customer, item, category, qty, price, order_date, due, notes)
    print(c(f"\n  ✓ Recorded {o.order_id} - total {o.total:,.2f}, status: {o.status}", GREEN))
    if o.total >= reports.HIGH_VALUE_LIMIT:
        print(c(f"  ⚠ High-value order (>= {reports.HIGH_VALUE_LIMIT:,.0f}) - please double-check.", YELLOW))


def update_status(book: OrderBook) -> None:
    oid = v.ask("\n  Order ID (e.g. ORD-0007 or 7)", v.parse_order_id)
    try:
        o = book.get(oid)
    except KeyError as exc:
        print(c(f"  ✗ {exc.args[0]}", RED)); return
    nxt = book.next_status(o)
    print(f"  {o.order_id}: {o.item} for {o.customer} - currently "
          f"{c(o.status, STATUS_COLOR[o.status])}")
    if nxt is None:
        print(c("  This order is closed; nothing to update.", YELLOW)); return
    choice = v.ask(f"  [A]dvance to '{nxt}', [C]ancel order, or [B]ack",
                   lambda s: s.lower() if s.lower() in {"a", "c", "b"}
                   else (_ for _ in ()).throw(ValueError("Enter A, C or B.")))
    if choice == "a":
        book.advance(oid); print(c(f"  ✓ {oid} is now {nxt}.", GREEN))
    elif choice == "c":
        if v.ask("  Type YES to confirm cancellation", None).upper() == "YES":
            book.cancel(oid); print(c(f"  ✓ {oid} cancelled.", GREEN))
        else:
            print("  Cancellation aborted.")


def search(book: OrderBook) -> None:
    print(c("\n  Search (leave blank to skip a filter)", BOLD))
    kw = v.ask("  Keyword (id / customer / item / notes)", None, default="")
    cat = v.ask(f"  Category ({'/'.join(CATEGORIES)})",
                lambda s: v.parse_category(s) if s else "", default="")
    st = v.ask(f"  Status ({'/'.join(STATUSES)})",
               lambda s: v.parse_status(s) if s else "", default="")
    print_table(book.search(kw, cat, st))


def details(book: OrderBook) -> None:
    oid = v.ask("\n  Order ID", v.parse_order_id)
    try:
        o = book.get(oid)
    except KeyError as exc:
        print(c(f"  ✗ {exc.args[0]}", RED)); return
    print(c(f"\n  {o.order_id}", BOLD))
    for label, val in [("Customer", o.customer), ("Item", o.item), ("Category", o.category),
                       ("Quantity", o.quantity), ("Unit price", f"{o.unit_price:,.2f}"),
                       ("Total", f"{o.total:,.2f}"), ("Ordered", o.order_date),
                       ("Due", o.due_date), ("Status", o.status), ("Notes", o.notes or "-")]:
        print(f"  {label:<11}: {val}")
    print("  History    :")
    for h in o.history:
        print(f"    {h['at']}  {h['status']}")


def summary(book: OrderBook) -> None:
    print("\n" + reports.format_text(reports.compute_summary(book.orders)))


def warnings(book: OrderBook) -> None:
    od = book.overdue()
    if not od:
        print(c("\n  ✓ No overdue orders.", GREEN)); return
    print(c(f"\n  ⚠ {len(od)} overdue order(s):", RED))
    today = date.today()
    for o in od:
        print(c(f"   {o.order_id}  {o.customer:<18} {o.status:<11} "
                f"due {o.due_date}  ({o.days_overdue(today)} day"
                f"{'s' if o.days_overdue(today) != 1 else ''} late)", YELLOW))
    big = [o for o in book.orders if o.total >= reports.HIGH_VALUE_LIMIT and o.status != "cancelled"]
    for o in big:
        print(c(f"   ⚠ High-value: {o.order_id} total {o.total:,.2f}", YELLOW))


def export(book: OrderBook, out_dir: Path) -> None:
    files = reports.export_all(book.orders, out_dir)
    print(c("\n  ✓ Exported:", GREEN))
    for f in files:
        print(f"    {f}")


def bulk_import(book: OrderBook, data_dir: Path) -> None:
    path = v.ask("\n  Path to CSV file", lambda s: s if s else (_ for _ in ()).throw(
        ValueError("Please enter a path.")))
    imported, errors = import_csv(book, path.strip('"\''), data_dir / "import_errors.log")
    print(c(f"  ✓ Imported {imported} order(s).", GREEN))
    if errors:
        print(c(f"  ✗ {len(errors)} row(s) rejected (details in import_errors.log):", RED))
        for e in errors[:10]:
            print(f"    {e}")
        if len(errors) > 10:
            print(f"    ... and {len(errors) - 10} more")


# ---- main loop ---------------------------------------------------------------
def run(data_file: Path, export_dir: Path) -> None:
    book = OrderBook(data_file)
    print(c(BANNER, CYAN))
    for w in book.load_warnings:
        print(c(f"  ⚠ {w}", YELLOW))
    n_over = len(book.overdue())
    print(f"\n  {len(book.orders)} orders loaded."
          + (c(f"  ⚠ {n_over} overdue!", RED) if n_over else ""))
    actions = {
        "1": lambda: add_order(book), "2": lambda: update_status(book),
        "3": lambda: print_table(book.orders), "4": lambda: search(book),
        "5": lambda: details(book), "6": lambda: summary(book),
        "7": lambda: warnings(book), "8": lambda: export(book, export_dir),
        "9": lambda: bulk_import(book, data_file.parent),
    }
    while True:
        print(MENU)
        try:
            choice = input("\n  Choose an option: ").strip()
        except (EOFError, KeyboardInterrupt):
            choice = "0"
        if choice == "0":
            print(c("\n  Data saved. Goodbye!\n", GREEN)); break
        action = actions.get(choice)
        if not action:
            print(c("  ✗ Please choose a number from the menu (0-9).", RED)); continue
        try:
            action()
        except v.Cancelled:
            print(c("  Cancelled - back to menu.", YELLOW))
        except (EOFError, KeyboardInterrupt):
            print(c("\n  Interrupted - back to menu.", YELLOW))
        except Exception as exc:  # last-resort guard so the demo never crashes
            print(c(f"  ✗ Unexpected error: {exc}", RED))
