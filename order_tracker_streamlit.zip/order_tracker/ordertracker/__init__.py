"""Simple Order Tracker - SmartCommunity Hack, Project #85."""
__version__ = "1.0.0"
