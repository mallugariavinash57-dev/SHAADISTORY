"""Defensive input validation.

Every ``parse_*`` function raises ``ValueError`` with a friendly message, so the
same rules protect interactive prompts, CSV imports and the business logic.
"""
from __future__ import annotations

import math
import re
from datetime import datetime

from .models import CATEGORIES, STATUSES

MAX_QTY = 1000
MIN_PRICE, MAX_PRICE = 0.01, 100_000.00


class Cancelled(Exception):
    """Raised when the user types 'cancel' at a prompt."""


def clean_text(value, field_name: str, min_len: int = 2, max_len: int = 60) -> str:
    text = re.sub(r"[\x00-\x1f\x7f]", " ", str(value if value is not None else ""))
    text = re.sub(r"\s+", " ", text).strip()
    if len(text) < min_len:
        raise ValueError(f"{field_name} must be at least {min_len} characters.")
    if len(text) > max_len:
        raise ValueError(f"{field_name} must be at most {max_len} characters.")
    return text


def parse_quantity(value) -> int:
    s = str(value).strip()
    if not re.fullmatch(r"\d+", s):
        raise ValueError("Quantity must be a whole number (e.g. 3).")
    n = int(s)
    if not 1 <= n <= MAX_QTY:
        raise ValueError(f"Quantity must be between 1 and {MAX_QTY}.")
    return n


def parse_price(value) -> float:
    s = str(value).strip().replace(",", "").lstrip("$₹")
    try:
        p = float(s)
    except ValueError:
        raise ValueError("Price must be a number (e.g. 49.99).") from None
    if math.isnan(p) or math.isinf(p):
        raise ValueError("Price must be a finite number.")
    if not MIN_PRICE <= p <= MAX_PRICE:
        raise ValueError(f"Price must be between {MIN_PRICE} and {MAX_PRICE:,.2f}.")
    return round(p, 2)


def parse_date(value) -> str:
    try:
        return datetime.strptime(str(value).strip(), "%Y-%m-%d").date().isoformat()
    except ValueError:
        raise ValueError("Date must be a real date in YYYY-MM-DD format.") from None


def parse_category(value) -> str:
    c = str(value).strip().lower()
    if c not in CATEGORIES:
        raise ValueError(f"Category must be one of: {', '.join(CATEGORIES)}.")
    return c


def parse_status(value) -> str:
    s = str(value).strip().lower()
    if s not in STATUSES:
        raise ValueError(f"Status must be one of: {', '.join(STATUSES)}.")
    return s


def validate_dates(order_date: str, due_date: str) -> None:
    if due_date < order_date:
        raise ValueError("Due date cannot be earlier than the order date.")


def parse_order_id(value) -> str:
    s = str(value).strip().upper()
    if re.fullmatch(r"\d+", s):
        s = f"ORD-{int(s):04d}"
    if not re.fullmatch(r"ORD-\d{4,}", s):
        raise ValueError("Order ID looks like ORD-0001 (or just the number).")
    return s


# ---- interactive prompt wrapper -------------------------------------------
def ask(prompt: str, parser=None, default: str | None = None, input_fn=input):
    """Loop until `parser` accepts the input. Type 'cancel' to abort."""
    suffix = f" [{default}]" if default else ""
    while True:
        raw = input_fn(f"{prompt}{suffix}: ").strip()
        if raw.lower() == "cancel":
            raise Cancelled()
        if not raw and default is not None:
            raw = default
        try:
            return parser(raw) if parser else raw
        except ValueError as exc:
            print(f"  ✗ {exc}")
