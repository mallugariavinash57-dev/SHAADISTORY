"""Core data structures for the Order Tracker."""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from datetime import date

STATUS_FLOW = ["placed", "processing", "shipped", "delivered"]
STATUSES = STATUS_FLOW + ["cancelled"]
CLOSED_STATUSES = {"delivered", "cancelled"}
CATEGORIES = ["electronics", "grocery", "clothing", "stationery", "home", "other"]


@dataclass
class Order:
    order_id: str
    customer: str
    item: str
    category: str
    quantity: int
    unit_price: float
    order_date: str          # ISO YYYY-MM-DD
    due_date: str            # ISO YYYY-MM-DD
    status: str = "placed"
    notes: str = ""
    history: list = field(default_factory=list)  # [{"status":..., "at":...}]

    @property
    def total(self) -> float:
        return round(self.quantity * self.unit_price, 2)

    def is_overdue(self, today: date | None = None) -> bool:
        today = today or date.today()
        return (self.status not in CLOSED_STATUSES
                and date.fromisoformat(self.due_date) < today)

    def days_overdue(self, today: date | None = None) -> int:
        today = today or date.today()
        return max(0, (today - date.fromisoformat(self.due_date)).days)

    def delivered_on(self) -> str | None:
        for h in self.history:
            if h.get("status") == "delivered":
                return h["at"][:10]
        return None

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Order":
        return cls(
            order_id=str(d["order_id"]), customer=d["customer"], item=d["item"],
            category=d["category"], quantity=int(d["quantity"]),
            unit_price=float(d["unit_price"]), order_date=d["order_date"],
            due_date=d["due_date"], status=d.get("status", "placed"),
            notes=d.get("notes", ""), history=list(d.get("history", [])),
        )
