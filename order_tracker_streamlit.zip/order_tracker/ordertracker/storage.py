"""JSON persistence with corruption recovery and atomic writes."""
from __future__ import annotations

import json
import os
import shutil
import tempfile
from datetime import datetime
from pathlib import Path

from .models import Order
from . import validation as v

SCHEMA_VERSION = 1


def _check_record(d: dict) -> Order:
    """Schema check for one stored record; raises ValueError/KeyError if bad."""
    o = Order.from_dict(d)
    v.clean_text(o.customer, "Customer")
    v.clean_text(o.item, "Item")
    v.parse_category(o.category)
    v.parse_quantity(o.quantity)
    v.parse_price(o.unit_price)
    v.validate_dates(v.parse_date(o.order_date), v.parse_date(o.due_date))
    v.parse_status(o.status)
    v.parse_order_id(o.order_id)
    return o


def load_orders(path: Path) -> tuple[list[Order], list[str]]:
    """Return (orders, warnings). Never raises on bad/missing files."""
    path = Path(path)
    warnings: list[str] = []
    if not path.exists():
        save_orders(path, [])
        warnings.append(f"No data file found - created a fresh one at {path}.")
        return [], warnings
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        records = payload["orders"]
        if not isinstance(records, list):
            raise TypeError("'orders' must be a list")
    except (json.JSONDecodeError, KeyError, TypeError, UnicodeDecodeError) as exc:
        backup = path.with_suffix(f".corrupt-{datetime.now():%Y%m%d%H%M%S}.json")
        shutil.copy2(path, backup)
        save_orders(path, [])
        warnings.append(f"Data file was unreadable ({exc.__class__.__name__}). "
                        f"Backed up to {backup.name} and started fresh.")
        return [], warnings

    orders, skipped = [], 0
    for rec in records:
        try:
            orders.append(_check_record(rec))
        except (ValueError, KeyError, TypeError):
            skipped += 1
    if skipped:
        warnings.append(f"Skipped {skipped} invalid record(s) while loading.")
    return orders, warnings


def save_orders(path: Path, orders: list[Order]) -> None:
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    payload = {"schema_version": SCHEMA_VERSION,
               "orders": [o.to_dict() for o in orders]}
    fd, tmp = tempfile.mkstemp(dir=path.parent, suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(payload, fh, indent=2, ensure_ascii=False)
        os.replace(tmp, path)          # atomic: no half-written files
    except Exception:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
