"""Core business logic: record orders and move them from placed to delivered."""
from __future__ import annotations

from datetime import date, datetime
from pathlib import Path

from . import storage, validation as v
from .models import Order, STATUS_FLOW, CLOSED_STATUSES


class OrderBook:
    def __init__(self, path):
        self.path = Path(path)
        self.orders, self.load_warnings = storage.load_orders(self.path)

    # ---- helpers ----------------------------------------------------------
    def save(self) -> None:
        storage.save_orders(self.path, self.orders)

    def _next_id(self) -> str:
        nums = [int(o.order_id.split("-")[1]) for o in self.orders]
        return f"ORD-{max(nums, default=0) + 1:04d}"

    def get(self, order_id: str) -> Order:
        oid = v.parse_order_id(order_id)
        for o in self.orders:
            if o.order_id == oid:
                return o
        raise KeyError(f"No order found with ID {oid}.")

    # ---- create -----------------------------------------------------------
    def add(self, customer, item, category, quantity, unit_price,
            order_date, due_date, notes="", status="placed",
            save: bool = True, now: datetime | None = None) -> Order:
        od = v.parse_date(order_date)
        dd = v.parse_date(due_date)
        v.validate_dates(od, dd)
        status = v.parse_status(status)
        stamp = (now or datetime.now()).isoformat(timespec="seconds")
        order = Order(
            order_id=self._next_id(),
            customer=v.clean_text(customer, "Customer"),
            item=v.clean_text(item, "Item"),
            category=v.parse_category(category),
            quantity=v.parse_quantity(quantity),
            unit_price=v.parse_price(unit_price),
            order_date=od, due_date=dd, status=status,
            notes=v.clean_text(notes, "Notes", 0, 200) if notes else "",
            history=[{"status": status, "at": stamp}],
        )
        self.orders.append(order)
        if save:
            self.save()
        return order

    # ---- status updates ---------------------------------------------------
    def next_status(self, order: Order) -> str | None:
        if order.status in CLOSED_STATUSES:
            return None
        return STATUS_FLOW[STATUS_FLOW.index(order.status) + 1]

    def advance(self, order_id: str, now: datetime | None = None) -> Order:
        order = self.get(order_id)
        nxt = self.next_status(order)
        if nxt is None:
            raise ValueError(f"{order.order_id} is already {order.status}; "
                             "it cannot be updated further.")
        order.status = nxt
        order.history.append({"status": nxt,
                              "at": (now or datetime.now()).isoformat(timespec="seconds")})
        self.save()
        return order

    def cancel(self, order_id: str, now: datetime | None = None) -> Order:
        order = self.get(order_id)
        if order.status in CLOSED_STATUSES:
            raise ValueError(f"{order.order_id} is already {order.status}.")
        order.status = "cancelled"
        order.history.append({"status": "cancelled",
                              "at": (now or datetime.now()).isoformat(timespec="seconds")})
        self.save()
        return order

    # ---- query ------------------------------------------------------------
    def search(self, keyword: str = "", category: str = "", status: str = "") -> list[Order]:
        kw = keyword.strip().lower()
        out = []
        for o in self.orders:
            if category and o.category != category:
                continue
            if status and o.status != status:
                continue
            if kw and kw not in f"{o.order_id} {o.customer} {o.item} {o.notes}".lower():
                continue
            out.append(o)
        return out

    def overdue(self, today: date | None = None) -> list[Order]:
        today = today or date.today()
        return sorted((o for o in self.orders if o.is_overdue(today)),
                      key=lambda o: o.due_date)
