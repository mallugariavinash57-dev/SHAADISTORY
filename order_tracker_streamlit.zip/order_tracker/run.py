#!/usr/bin/env python3
"""Launcher:  python run.py [--seed] [--data PATH]"""
import argparse
import shutil
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT))

from ordertracker import ui  # noqa: E402


def main() -> None:
    p = argparse.ArgumentParser(description="Simple Order Tracker")
    p.add_argument("--data", default=str(ROOT / "data" / "orders.json"),
                   help="path to the JSON data file")
    p.add_argument("--seed", action="store_true",
                   help="replace data file with the 40-order demo dataset")
    args = p.parse_args()
    data = Path(args.data)
    if args.seed:
        data.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(ROOT / "data" / "sample_orders.json", data)
        print(f"Seeded {data} with demo data.")
    ui.run(data, ROOT / "exports")


if __name__ == "__main__":
    main()
