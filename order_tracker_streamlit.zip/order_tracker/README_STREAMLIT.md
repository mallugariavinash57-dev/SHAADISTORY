# Order Tracker — Streamlit interface

From this folder, run:

```bash
python -m pip install -r requirements.txt
python -m streamlit run app.py
```

The app provides an order dashboard, searchable/filterable register, order creation and status transitions, fulfillment reports, CSV import, and local report downloads. Data persists in `data/orders.json`; exports are written to `exports/`.

See `README.md` for the original business rules and CSV format.
